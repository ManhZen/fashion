import { Component } from '@angular/core';
import { ProductService } from 'src/app/core/services/product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'VLYN';

  constructor(private productService: ProductService) {
    this.productService.getAllProducts().subscribe();
  }
}
