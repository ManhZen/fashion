import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from 'src/app/core/services/cart.service';
import { DestroyService } from 'src/app/core/services/destroy.service';
import { map, takeUntil, tap } from 'rxjs/operators';
import { ICartItem } from 'src/app/core/models';
import { AuthService } from 'src/app/core/services/auth.service';
import { NzModalService } from 'ng-zorro-antd/modal';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  @ViewChild('searchBox') searchBox: ElementRef<HTMLInputElement> | undefined;
  item_amount: number = 0;
  isLogin = false;
  imageUrl: string = '';
  isAdmin = false;
  
  constructor(
    private router: Router,
    private cartService: CartService,
    private destroy$: DestroyService,
    private authService: AuthService,
    private modal: NzModalService
  ) {}

  ngOnInit(): void {
    this.listenCartAmount();
    this.authService.currentUser$
      .pipe(
        tap((_user) => {
          if (Object.keys(_user).length) {
            this.isLogin = true;
            this.isAdmin = _user.isAdmin
          }
        }),
        takeUntil(this.destroy$)
      )
      .subscribe((_user) => {
        this.imageUrl = _user.photoURL;
      });
  }

  handleSearch() {
    const search_value = this.searchBox?.nativeElement.value;
    if (search_value && search_value?.length > 0) {
      this.router.navigate(['/products/search'], {
        queryParams: {
          keyword: search_value,
        },
      });
    }
  }

  onLogout() {
    this.authService.SignOut().then(
      () => {
        this.modal.success({
          nzTitle: 'Đăng xuất thành công',
          nzClosable: false,
          nzOnOk: async () => {
            await this.router.navigate(['/']);
            window.location.reload();
          },
        });
      },
      (err) => {
        this.modal.error({
          nzTitle: err,
          nzClosable: false,
          nzOnOk: async () => {
            await this.router.navigate(['/']);
            window.location.reload();
          },
        });
      }
    );
  }

  private listenCartAmount(): void {
    this.cartService.cart$.pipe(takeUntil(this.destroy$)).subscribe((carts) => {
      this.item_amount = carts.length;
    });
  }
}
