import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IBuyerInfo } from 'src/app/core/models';
import { isFieldInFormInvalid, markFormGroupTouched } from "src/app/core/services/form";
import { filter, takeUntil } from "rxjs/operators";
import { DestroyService } from "src/app/core/services/destroy.service";

@Component({
  selector: 'app-billing-address-form',
  templateUrl: './billing-address-form.component.html',
  styleUrls: ['./billing-address-form.component.css'],
})
export class BillingAddressFormComponent implements OnInit, OnChanges {
  billingForm: FormGroup;
  
  @Input() isEmitValue = false;
  @Input() formValue: any;
  @Output() emitFormValue = new EventEmitter<IBuyerInfo>();
  @Output() isInvalidForm = new EventEmitter<boolean>();
  
  constructor( private fb: FormBuilder, private destroy$: DestroyService ) {
    this.billingForm = this.fb.group({
      fullName: [null, [Validators.required, Validators.maxLength(255)]],
      phone: [
        null,
        [
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(11),
        ],
      ],
      address: [null, [Validators.required, Validators.maxLength(255)]],
      provinceId: [null, [Validators.required]],
      districtId: [null, [Validators.required]],
      wardId: [null, [Validators.required]],
      paymentMethodId: [null, [Validators.required]],
      deliveryMethodId: [null, [Validators.required]],
    });
  }
  
  ngOnInit(): void {
    this.billingForm.valueChanges
        .pipe(takeUntil(this.destroy$))
        .subscribe(res => {
          const isInvalid = this.billingForm.invalid;
              this.isInvalidForm.emit(isInvalid);
              if (!isInvalid) {
                console.log(this.billingForm.value)
                this.emitFormValue.emit(this.billingForm.value)
              }
            }
        )
  }
  
  ngOnChanges( changes: SimpleChanges ): void {
    // if (this.billingForm.invalid) {
    //   return;
    // } else {
    //   console.log(this.billingForm.value)
    // }
  }
  
  isFieldInValid( field: string, error: string ): boolean {
    return isFieldInFormInvalid(this.billingForm, field, error);
  }
}
