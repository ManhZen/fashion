import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BillingAddressFormComponent } from './billing-address-form.component';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { OnlyNumberDirective } from "src/app/core/directives";
import { ReactiveFormsModule } from "@angular/forms";
import { NzFormModule } from "ng-zorro-antd/form";
const DIRECTIVES = [OnlyNumberDirective];

@NgModule({
  declarations: [BillingAddressFormComponent, ...DIRECTIVES],
	imports: [CommonModule, NzSelectModule, NzRadioModule, ReactiveFormsModule, NzFormModule],
  exports: [BillingAddressFormComponent],
})
export class BillingAddressFormModule {}
