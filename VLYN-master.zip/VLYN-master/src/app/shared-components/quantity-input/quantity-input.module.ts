import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuantityInputComponent } from './quantity-input.component';

@NgModule({
  declarations: [QuantityInputComponent],
  imports: [CommonModule],
  exports: [QuantityInputComponent],
})
export class QuantityInputModule {}
