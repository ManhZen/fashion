import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-quantity-input',
  templateUrl: './quantity-input.component.html',
  styleUrls: ['./quantity-input.component.css'],
})
export class QuantityInputComponent implements OnInit {
  @Input() quantity = 1;
  @Input() isCheckEmpty = true;
  @Input() maxQuantity = 1;
  @Output() clickSubtractItem = new EventEmitter<number>();
  @Output() clickAddItem = new EventEmitter<number>();
  @Output() emitQuantity = new EventEmitter<number>();
  
  constructor() {
  }
  
  ngOnInit(): void {
  }

  remove(): void {
    if (this.isCheckEmpty && this.quantity === 1) return;
    --this.quantity;
    this.clickSubtractItem.emit(this.quantity);
    this.emitQuantity.emit(this.quantity);
  }
  
  add(): void {
    if (this.maxQuantity === this.quantity) return;
    ++this.quantity;
    this.clickAddItem.emit(this.quantity);
    this.emitQuantity.emit(this.quantity);
  }
}
