import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NzFormatEmitEvent } from 'ng-zorro-antd/tree';
import { ICategory } from 'src/app/core/models';
import { ProductService } from 'src/app/core/services/product.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css'],
})
export class LayoutComponent implements OnInit {
  categories: any = [];

  constructor(private productService: ProductService, private router: Router) {}

  ngOnInit(): void {
    this.productService.getAllCategories().subscribe((categories) => {
      this.categories = categories;
    });
  }

  handleNavigation(event: NzFormatEmitEvent) {
    this.router.navigate(['/products/category', event.node!.title], {
      queryParams: {
        cateId: event.node?.key,
      },
    });
  }
}
