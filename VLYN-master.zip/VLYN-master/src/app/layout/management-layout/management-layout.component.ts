import { Component, OnInit } from '@angular/core';
import { takeUntil } from 'rxjs/operators';
import { IUser } from 'src/app/core/models';
import { AuthService } from 'src/app/core/services/auth.service';
import { DestroyService } from 'src/app/core/services/destroy.service';

@Component({
  selector: 'app-management-layout',
  templateUrl: './management-layout.component.html',
  styleUrls: ['./management-layout.component.css'],
})
export class ManagementLayoutComponent implements OnInit {
  isAdmin = false;
  currentUser: IUser;

  constructor(
    private authService: AuthService,
    private destroy$: DestroyService
  ) {}

  ngOnInit(): void {
    this.authService.currentUser$
      .pipe(takeUntil(this.destroy$))
      .subscribe((currentUser) => {
        this.isAdmin = currentUser.isAdmin;
        this.currentUser = currentUser;
      });
  }
}
