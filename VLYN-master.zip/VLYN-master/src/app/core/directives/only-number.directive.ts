import { Directive, HostListener } from '@angular/core';

@Directive({ selector: '[only-number]' })
export class OnlyNumberDirective {
  @HostListener('input', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    const input = event.target as HTMLInputElement;

    let trimmed = input.value.replace(/\s+/g, '');
    trimmed = input.value.replace(/\D/g, '');

    let numbers = [];
    for (let i = 0; i < trimmed.length; i += 1) {
      numbers.push(trimmed.substr(i, 1));
    }

    input.value = numbers.join('');
  }
}
