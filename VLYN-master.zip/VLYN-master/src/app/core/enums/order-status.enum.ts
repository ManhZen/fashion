export enum OrderStatus {
	PENDING ='PENDING',
	PLACED = 'PLACED',
	AWAIT_PAYMENT = 'AWAIT_PAYMENT',
	SHIPPING = 'SHIPPING',
	DELIVERED = 'DELIVERED',
	SUCCESS = 'SUCCESS',
	CANCELLED = 'CANCELLED',
	DISPUTE = 'DISPUTE',
}

export const OrderStatusVN = new Map ([
	['PENDING', 'Chờ thanh toán'],
	['PLACED', "Chờ lấy hàng" ],
	['AWAIT_PAYMENT', "Chờ xác nhận"],
	['SHIPPING', 'Đang vận chuyển'],
	['SUCCESS', 'Đã giao'],
	['CANCELLED', 'Đã huỷ'],
	['DISPUTE', 'Khiếu nại'],
])

export const OrderStatusToClass = new Map([
	['PLACED', 'await_shipping'],
	['PENDING', 'pending'],
	['SHIPPING', 'shipping'],
	['SUCCESS', 'success'],
	['CANCELLED', 'cancel'],
])

export const OrderTabTitleToStatus = new Map([
	['Tất cả', 'ALL'],
	['Chờ xác nhận', 'PENDING'],
	['Chờ lấy hàng', 'PLACED'],
	['Đang vận chuyển', 'SHIPPING'],
	['Đã giao', 'SUCCESS'],
	['Đã hủy', 'CANCELLED']
])
