export interface ICategory {
  key: string;
  title: string;
  alias: string;
  parentId?: string | null;
  children?: ICategory[];
  isLeaf?: boolean;
  expanded?: boolean;
}
