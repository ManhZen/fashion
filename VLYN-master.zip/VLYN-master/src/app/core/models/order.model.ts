import { ICartItem } from 'src/app/core/models';
import { OrderStatus } from 'src/app/core/enums';

export interface IOrder extends IBuyerInfo {
  id: string;
  items: ICartItem[];
  status: OrderStatus;
  price: number;
  shippingCost: number;
  discountCost: number;
  totalPayment: number;
  amount: number;
  buyer_id: string;
}

export interface IBuyerInfo {
  fullName: string;
  phone: string;
  provinceId: string;
  districtId: string;
  wardId: string;
  address: string;
  paymentMethodId: string;
  deliveryMethodId: string;
}
