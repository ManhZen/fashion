export interface ICartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  sku: string;
  address: any;
  maxQuantity: number;
  inCheckout?: boolean;
}
