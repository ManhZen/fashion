export interface IProduct {
  id: string;
  name: string;
  description: string;
  alias?: string;
  catId: string;
  catTitle: string;
  quantity: number;
  orderedAmount?: number;
  unitPrice: number;
  saleAmount?: number;
  salePrice?: number;
  images: string[];
  colors: string[];
  sizes: string[];
  parentCatId?: string;
}
