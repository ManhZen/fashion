import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, shareReplay, tap } from 'rxjs/operators';
import { ICategory, IProduct } from 'src/app/core/models';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private categories = new BehaviorSubject<ICategory[]>([
    {
      key: '1',
      title: 'ÁO',
      alias: 'ao',
      expanded: true,
      children: [
        {
          key: '7',
          title: 'Sweater',
          alias: 'sweater',
          parentId: '1',
          isLeaf: true
        },
        {
          key: '8',
          title: 'Sơ Mi',
          alias: 'so-mi',
          parentId: '1',
          isLeaf: true
        },
        {
          key: '9',
          title: 'Hoodie',
          alias: 'hoodie',
          parentId: '1',
          isLeaf: true,
        },
        {
          key: '10',
          title: 'Áo Thun',
          alias: 'ao-thun',
          parentId: '1',
          isLeaf: true,
        },
        {
          key: '11',
          title: 'Cardigan',
          alias: 'cardigan',
          parentId: '1',
          isLeaf: true,
        },
        {
          key: '12',
          title: 'Áo Khoác',
          alias: 'ao-khoac',
          parentId: '1',
          isLeaf: true,
        },
      ],
    },
    {
      key: '2',
      title: 'QUẦN',
      alias: 'quan',
      children: [
        {
          key: '13',
          title: 'Quần Jean',
          alias: 'Quan-jean',
          parentId: '2',
          isLeaf: true,
  
        },
        {
          key: '14',
          title: 'Quần Nỉ',
          alias: 'Quan-ni',
          parentId: '2',
          children: [],
          isLeaf: true,
  
        },
        {
          key: '15',
          title: 'Quần Short',
          alias: 'Quan-short',
          parentId: '2',
          isLeaf: true,
  
        },
        {
          key: '16',
          title: 'Quần Trouser',
          alias: 'Quan-trouser',
          parentId: '2',
          isLeaf: true,
        },
      ],
    },
    {
      key: '3',
      title: 'VÁY',
      alias: 'vay',
      parentId: null,
      children: [
        {
          key: '17',
          title: 'Váy Liền Thân',
          alias: 'vay-lien-than',
          parentId: '3',
          isLeaf: true
        },
        {
          key: '18',
          title: 'Chân Váy Ngắn',
          alias: 'chan-vay-ngan',
          parentId: '3',
          isLeaf: true
        },
        {
          key: '19',
          title: 'Chân Váy Dài',
          alias: 'chan-vay-dai',
          parentId: '3',
          isLeaf: true
        },
      ],
    },
    {
      key: '4',
      title: 'GIÀY',
      alias: 'giay',
      parentId: null,
      children: [],
      isLeaf: true,
    },
    {
      key: '5',
      title: 'MŨ',
      alias: 'mu',
      parentId: null,
      children: [],
      isLeaf: true,
    },
    {
      key: '6',
      title: 'TRANG SỨC',
      alias: 'trang-suc',
      parentId: null,
      children: [],
      isLeaf: true,
    },
  ]);
  categories$ = this.categories.asObservable().pipe(shareReplay());

  private allProducts = new BehaviorSubject<IProduct[]>([]);
  allProducts$ = this.allProducts.asObservable().pipe(shareReplay());

  private searchResults = new BehaviorSubject<IProduct[]>([]);
  searchResults$ = this.searchResults.asObservable().pipe(shareReplay());

  constructor(private fireStore: AngularFirestore) {}

  getAllCategories() {
    return this.categories$;
  }

  getAllProducts() {
    return this.fireStore
      .collection('/products', (ref) => ref.orderBy('updatedAt', 'desc'))
      .snapshotChanges()
      .pipe(
        map((documents: any) => {
          return documents.map((doc: any) => {
            const actual_data = doc.payload.doc.data();
            return { ...actual_data, id: doc.payload.doc.id };
          });
        }),
        tap((products) => {
          this.allProducts.next(products);
        })
      );
  }

  getSingleProduct(product_id: string): Observable<IProduct> {
    return this.fireStore
      .collection('/products')
      .doc(product_id)
      .valueChanges() as Observable<IProduct>;
  }

  getLatestProducts(): Observable<IProduct[]> {
    return this.fireStore
      .collection('/products', (ref) =>
        ref.limit(20).orderBy('updatedAt', 'desc')
      )
      .snapshotChanges()
      .pipe(
        map((documents: any) => {
          return documents.map((doc: any) => {
            const actual_data = doc.payload.doc.data();
            return { ...actual_data, id: doc.payload.doc.id };
          });
        })
      );
  }

  getSaleProducts(): Observable<IProduct[]> {
    return this.fireStore
      .collection('/products', (ref) =>
        ref.where('saleAmount', '>', 0).limit(20).orderBy('saleAmount', 'desc')
      )
      .snapshotChanges()
      .pipe(
        map((documents: any) => {
          return documents.map((doc: any) => {
            const actual_data = doc.payload.doc.data();
            return { ...actual_data, id: doc.payload.doc.id };
          });
        })
      );
  }

  getProductByCate(catId: string): Observable<IProduct[]> {
    return this.getAllProducts().pipe(
      map((products) =>
        products.filter(
          (product: IProduct) =>
            product.catId == catId || product.parentCatId == catId
        )
      )
    );
  }

  createProduct(product: IProduct) {
    return this.fireStore
      .collection('/products')
      .add({ ...product, updatedAt: Date.now() });
  }

  updateProduct(product_id: string, updated_product: IProduct) {
    return this.fireStore
      .collection('/products')
      .doc(product_id)
      .set({ ...updated_product, updatedAt: Date.now() });
  }

  deleteProduct(product_id: string) {
    return this.fireStore.doc('/products/' + product_id).delete();
  }

  searchProducts(search_value: string) {
    const all_products = this.allProducts.value;
    if (all_products.length === 0) {
      this.fireStore
        .collection('/products', (ref) => ref.orderBy('updatedAt', 'desc'))
        .snapshotChanges()
        .pipe(
          map((documents: any) => {
            return documents.map((doc: any) => {
              const actual_data = doc.payload.doc.data();
              return { ...actual_data, id: doc.payload.doc.id };
            });
          })
        )
        .subscribe((products) => {
          const matched_products = products.filter((product: IProduct) =>
            product.name.toLowerCase().includes(search_value.toLowerCase())
          );
          this.searchResults.next(matched_products);

          return;
        });
    }

    const matched_products = all_products.filter((product) =>
      product.name.toLowerCase().includes(search_value.toLowerCase())
    );

    this.searchResults.next(matched_products);
  }
}
