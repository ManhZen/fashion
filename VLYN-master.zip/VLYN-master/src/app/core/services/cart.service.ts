import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ICartItem } from 'src/app/core/models';

const CARTS_IN_STORAGE = 'carts_in_storage';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartStorage: ICartItem[] = [];
  private cart = new BehaviorSubject<ICartItem[]>([]);
  private selectedCartItems = new BehaviorSubject<ICartItem[]>([]);

  public cart$ = this.cart.asObservable();
  public selectedCartItems$ = this.selectedCartItems.asObservable();
  constructor() {
    this.init();
  }

  private init(): void {
    this.getLocalStorage();
    this.cart.next(this.cartStorage);
  }

  setLocalStorage(): void {
    localStorage.setItem(CARTS_IN_STORAGE, JSON.stringify(this.cartStorage));
  }

  getLocalStorage(): void {
    this.cartStorage = JSON.parse(
      localStorage.getItem(CARTS_IN_STORAGE) ?? '[]'
    ) as ICartItem[];
  }

  addToCart(_item: ICartItem): void {
    let isMatch = false;
    this.cartStorage.forEach((item) => {
      if (item.id === _item.id && item.sku === _item.sku) {
        isMatch = true;
        item.quantity += _item.quantity;
      }
    });
    if (!isMatch) {
      this.cartStorage = [_item, ...this.cartStorage];
    }
    this.setCartValue();
  }

  onChangeQuantity(newQuantity: number, _item: ICartItem): void {
    this.cartStorage.map((item) => {
      if (item.id === _item.id && item.sku === _item.sku) {
        item.quantity = newQuantity;
      }
    });
    this.setCartValue();
  }

  selectCartItems(data: ICartItem[]): void {
    this.selectedCartItems.next(data);
  }

  removeItemInCart(itemId: string, itemSku: string): void {
    this.cartStorage = this.cartStorage.filter(
      (item) => item.sku !== itemSku || item.id !== itemId
    );
    this.setCartValue();
  }

  removeCart(): void {
    this.cart.next([]);
    localStorage.removeItem(CARTS_IN_STORAGE);
  }

  revertItemQuantity(_item: ICartItem): void {
    this.cartStorage.forEach((item) => {
      if (item.sku === _item.sku) {
        item.quantity = 1;
      }
    });
    this.setCartValue();
  }

  private setCartValue(): void {
    this.cart.next(this.cartStorage);
    this.setLocalStorage();
  }
}
