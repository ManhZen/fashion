import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IOrder, IUser } from 'src/app/core/models';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  constructor(private fireStore: AngularFirestore) {}

  getAllOrders(): Observable<IOrder[]> {
    return this.fireStore
      .collection('/orders', (ref) => ref.orderBy('createdAt', 'desc'))
      .snapshotChanges()
      .pipe(
        map((documents: any) => {
          return documents.map((doc: any) => {
            const actual_data = doc.payload.doc.data();
            return { ...actual_data, id: doc.payload.doc.id };
          });
        })
      );
  }

  getSingleOrder(order_id: string): Observable<IOrder> {
    return this.fireStore
      .collection('/orders')
      .doc(order_id)
      .valueChanges() as Observable<IOrder>;
  }

  createOrder(order: IOrder, currentUser: IUser) {
    return this.fireStore
      .collection('/orders')
      .add({ ...order, buyer_id: currentUser.uid, createdAt: Date.now() });
  }

  updateOrder(order_id: string, updated_order: IOrder): Promise<void> {
    return this.fireStore
      .collection('/orders')
      .doc(order_id)
      .set({ ...updated_order, updatedAt: Date.now() });
  }

  deleteOrder(order_id: string): Promise<void> {
    return this.fireStore.doc('/orders/' + order_id).delete();
  }
}
