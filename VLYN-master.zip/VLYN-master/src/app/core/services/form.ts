import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';

export const markFormGroupTouched = (form: FormGroup): void => {
	Object.keys(form.controls).forEach((field: string) => {
		const control = form.get(field);
		control?.markAsTouched({ onlySelf: true });
	});
};

export const isFieldInFormInvalid = (form: FormGroup, field: string, error: string): boolean =>
	!!form.get(field)?.touched && !form.get(field)?.valid && !!form.get(field)?.errors?.[error];

export const addFormFieldValidators = (
	form: FormGroup,
	field: string,
	validators: ValidatorFn | ValidatorFn[] | null
): void => {
	form.controls[field].setValidators(validators);
	form.controls[field].updateValueAndValidity();
};

export const clearFormFieldValidators = (form: FormGroup, field: string): void => {
	form.controls[field].clearValidators();
	form.controls[field].updateValueAndValidity();
};

export const addControlToForm = ( form: FormGroup, field: string, validators?: ValidatorFn | ValidatorFn[] | null ): void => {
	form.addControl(field, new FormControl(null, validators));
}

export const removeControl = ( form: FormGroup, field: string ): void => {
	form.removeControl(field);
}
