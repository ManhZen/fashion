import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import {
  AngularFirestore,
  AngularFirestoreDocument,
} from '@angular/fire/compat/firestore';
import { Router } from '@angular/router';
import * as auth from 'firebase/auth';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { switchMap } from 'rxjs/internal/operators';
import { takeUntil } from 'rxjs/operators';
import { IUser, IUserAdmin } from 'src/app/core/models';
import { DestroyService } from 'src/app/core/services/destroy.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  userData!: IUserAdmin;
  private currentUser = new BehaviorSubject<IUserAdmin>({} as IUserAdmin);
  private logout = new Subject<void>();

  public currentUser$ = this.currentUser.asObservable();
  public logout$ = this.logout.asObservable();

  constructor(
    public afs: AngularFirestore,
    public afAuth: AngularFireAuth,
    public router: Router,
    private fireStore: AngularFirestore,
    private destroy$: DestroyService
  ) {
    this.saveAuth();
  }

  saveAuth(): void {
    this.afAuth.authState
      .pipe(
        switchMap((user) => this.getUserInDatabase(user?.uid)),
        takeUntil(this.destroy$)
      )
      .subscribe((user) => {
        if (user) {
          this.userData = user as IUserAdmin;
          this.currentUser.next(this.userData);
          localStorage.setItem('user', JSON.stringify(this.userData));
          JSON.parse(localStorage.getItem('user')!);
        } else {
          localStorage.setItem('user', 'null');
          this.currentUser.next({} as IUserAdmin);
          JSON.parse(localStorage.getItem('user')!);
        }
      });
  }

  SignIn(email: string, password: string) {
    return this.afAuth
      .signInWithEmailAndPassword(email, password)
      .then((result) => {
        console.log(result);
        this.SetUserData(result.user as IUser);
      });
  }

  SignUp(email: string, password: string) {
    return this.afAuth
      .createUserWithEmailAndPassword(email, password)
      .then(() => {
        this.SendVerificationMail();
      });
  }

  SendVerificationMail() {
    return this.afAuth.currentUser.then((u: any) => u.sendEmailVerification());
  }

  ForgotPassword(passwordResetEmail: string) {
    return this.afAuth
      .sendPasswordResetEmail(passwordResetEmail)
      .then(() => {
        window.alert('Password reset email sent, check your inbox.');
      })
      .catch((error) => {
        window.alert(error);
      });
  }

  get isLoggedIn(): boolean {
    const user = JSON.parse(localStorage.getItem('user')!);
    return user !== null && user.uid !== false;
  }

  GoogleAuth() {
    return this.AuthLogin(new auth.GoogleAuthProvider());
  }

  AuthLogin(provider: any) {
    return this.afAuth.signInWithPopup(provider).then((result) => {
      // TODO: thông báo login thành công
      this.SetUserData(result.user as IUser);
    });
  }

  SetUserData(user: IUser) {
    const userRef: AngularFirestoreDocument<any> = this.afs.doc(
      `users/${user.uid}`
    );
    const userData: IUser = {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      emailVerified: user.emailVerified,
    };
    return userRef.set(userData, {
      merge: true,
    });
  }

  // Sign out
  SignOut() {
    return this.afAuth.signOut().then(() => {
      localStorage.removeItem('user');
    });
  }

  getUserInDatabase(uid?: string): Observable<any> {
    return this.fireStore
      .collection('/users')
      .doc(uid)
      .valueChanges() as Observable<any>;
  }

  isAdmin(): boolean {
    return this.currentUser.value.isAdmin;
  }
}
