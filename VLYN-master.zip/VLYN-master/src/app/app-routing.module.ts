import { NgModule } from '@angular/core';
import { NoPreloading, RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/main-layout/layout.component';
import { ManagementLayoutComponent } from './layout/management-layout/management-layout.component';
import { AuthGuard } from "src/app/core/guards/auth.guard";

const routes: Routes = [
  {
    path: 'management',
    component: ManagementLayoutComponent,
    canActivate: [AuthGuard],
    loadChildren: () =>
      import('./features/management/management.module').then(
        (m) => m.ManagementModule
      ),
  },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'home',
        loadChildren: () =>
          import('./features/home/home.module').then((m) => m.HomeModule),
      },
      {
        path: 'auth',
        loadChildren: () =>
          import('./features/auth/auth.module').then((m) => m.AuthModule),
      },
      {
        path: 'products',
        loadChildren: () =>
          import('./features/products/products.module').then(
            (m) => m.ProductsModule
          ),
      },
      {
        path: 'cart',
        loadChildren: () =>
          import('./features/cart/cart.module').then((m) => m.CartModule),
      },
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: '**', redirectTo: 'home' },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'enabled',
    initialNavigation: 'enabled',
    preloadingStrategy: NoPreloading,
  }),],
  exports: [RouterModule],
})
export class AppRoutingModule {}
