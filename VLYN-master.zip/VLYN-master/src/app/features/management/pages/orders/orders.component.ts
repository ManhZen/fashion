import {
  AfterViewChecked,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { OrderService } from 'src/app/core/services/order.service';
import {
  OrderStatusToClass,
  OrderStatusVN,
  OrderTabTitleToStatus,
} from 'src/app/core/enums';
import { IUser } from 'src/app/core/models';
import { AuthService } from 'src/app/core/services/auth.service';
import { takeUntil } from 'rxjs/operators';
import { DestroyService } from 'src/app/core/services/destroy.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css'],
})
export class OrdersComponent implements OnInit, AfterViewChecked {
  tabs = [
    'Tất cả',
    'Chờ xác nhận',
    'Chờ lấy hàng',
    'Đang vận chuyển',
    'Đã giao',
    'Đã hủy',
  ];

  totalOrders: any = [];
  orders: any = [];

  currentUser: IUser;
  isAdmin = false;

  constructor(
    private orderService: OrderService,
    private authService: AuthService,
    private cdr: ChangeDetectorRef,
    private destroy$: DestroyService
  ) {}

  ngOnInit(): void {
    this.authService.currentUser$
      .pipe(takeUntil(this.destroy$))
      .subscribe((currentUser) => {
        this.currentUser = currentUser;
        this.isAdmin = this.authService.isAdmin();

        this.getAllOrders();
      });
  }

  ngAfterViewChecked(): void {
    this.cdr.detectChanges();
  }

  getAllOrders(): void {
    this.orderService.getAllOrders().subscribe((orders) => {
      this.totalOrders = orders;

      if (this.isAdmin) {
        this.orders = orders;
        return;
      }

      this.orders = orders.filter(
        (order) => order.buyer_id === this.currentUser.uid
      );
    });
  }

  getOrderStatus(status: string): string | undefined {
    return OrderStatusVN.get(status);
  }

  getOrderStatusClass(status: string): string {
    return String(OrderStatusToClass.get(status));
  }

  onChangeTab(tab: string): void {
    const status = OrderTabTitleToStatus.get(tab);
    if (status !== 'ALL') {
      this.orders = this.totalOrders.filter(
        (order: any) => order.status === status
      );
      return;
    }
    this.orders = this.totalOrders;
  }
}
