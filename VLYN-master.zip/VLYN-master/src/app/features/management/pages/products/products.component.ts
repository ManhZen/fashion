import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { NzTreeNode } from 'ng-zorro-antd/tree';
import { NzTreeSelectComponent } from 'ng-zorro-antd/tree-select';
import { NzUploadFile } from 'ng-zorro-antd/upload';
import { Subject } from 'rxjs';
import { filter, take, takeUntil } from 'rxjs/operators';
import { IProduct } from 'src/app/core/models';
import { ProductService } from 'src/app/core/services/product.service';

const getBase64 = (file: File): Promise<string | ArrayBuffer | null> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  @ViewChild('treeSelect', { static: false }) treeSelect!: NzTreeSelectComponent;
  @ViewChild('searchBox') searchBox: ElementRef<HTMLInputElement> | undefined;

  private readonly destroy$ = new Subject();
  products: IProduct[] = [];
  totalProducts: IProduct[] = [];
  searchValue: string;
  isModalVisible = false;
  modalTitle = 'Sản phẩm mới';

  productForm: FormGroup;
  sizes: Array<{ id: number; sizeControlInstance: string }> = [];
  colors: Array<{ id: number; colorControlInstance: string }> = [];
  images: string[] = [];

  onEdit = false;
  onEditProductId = '';

  debouncer: any;

  fileList: NzUploadFile[] = [];
  previewImage: string | undefined = '';
  previewVisible = false;

  categories: any[] = [];

  constructor(
    private fb: FormBuilder,
    private productService: ProductService,
    private fireStorage: AngularFireStorage
  ) {
    this.productForm = this.fb.group({
      name: [null, [Validators.required]],
      description: [null, Validators.required],
      images: [null, [Validators.required]],
      catId: [null, Validators.required],
      catTitle: [null, Validators.required],
      parentCatId: [null],
      quantity: [null, [Validators.required]],
      unitPrice: [null, [Validators.required]],
      saleAmount: [null],
      salePrice: [{ disabled: true, value: null }],
    });

    this.addSizeField();
    this.addColorField();
  }

  ngOnInit(): void {
    this.productService.categories$
      .pipe(takeUntil(this.destroy$))
      .subscribe((categories) => {
        this.categories = categories;
      });

    this.productService.allProducts$
      .pipe(takeUntil(this.destroy$))
      .subscribe((products) => {
        this.products = products;
        this.totalProducts = products;
      });
  }

  // popover methods
  handleConfirmPopover(product_id: string): void {
    this.productService.deleteProduct(product_id);
  }

  // modal methods
  showModal(product_id?: string): void {
    this.isModalVisible = true;

    if (product_id) {
      this.onEdit = true;
      this.modalTitle = 'Cập nhật sản phẩm';
      this.onEditProductId = product_id;

      this.patchValueToProductForm(product_id);
      return;
    } else {
      this.onEdit = false;
      this.modalTitle = 'Sản phẩm Mới';
      this.onEditProductId = '';
      this.productForm.reset();
      return;
    }
  }

  handleOkModal(): void {
    this.isModalVisible = false;
  }

  handleCancelModal(): void {
    // close modal
    this.isModalVisible = false;

    // reset form
    this.fileList = [];
    this.productForm.reset();
  }

  // form methods
  updateProduct() {
    if (!this.onEdit) {
      const new_product = this.productForm.getRawValue();
      this.productService.createProduct(new_product).then(() => {
        this.handleCancelModal();
      });

      return;
    }

    this.productService
      .updateProduct(this.onEditProductId, this.productForm.getRawValue())
      .then(() => {
        this.handleCancelModal();
      });
  }

  patchValueToProductForm(product_id: string) {
    this.productService
      .getSingleProduct(product_id)
      .pipe(take(1))
      .subscribe((product: IProduct | any) => {
        // patch images
        this.fileList = product.images.map((img: string, index: number) => ({
          uid: index,
          name: product.name,
          url: img,
        }));

        this.images = product.images;

        // patch dynamic form items (colors & sizes)
        const product_props = Object.keys(product);

        // get all sizes controls then use sort() to preserve the property's order
        const size_props = product_props
          .filter((prop) => prop.includes('sizes'))
          .sort((a, b) => {
            return (
              Number(a.substring(a.length - 1)) -
              Number(b.substring(b.length - 1))
            );
          });

        // get all colors controls then use sort() to preserve the property's order
        const color_props = product_props
          .filter((prop) => prop.includes('colors'))
          .sort((a, b) => {
            return (
              Number(a.substring(a.length - 1)) -
              Number(b.substring(b.length - 1))
            );
          });

        this.sizes = size_props.map((prop) => ({
          id: Number(prop.substring(prop.length - 1)),
          sizeControlInstance: prop,
        }));

        this.colors = color_props.map((prop) => ({
          id: Number(prop.substring(prop.length - 1)),
          colorControlInstance: prop,
        }));

        // add size controls to productForm then patch value to it
        this.sizes.forEach((size) => {
          this.productForm.addControl(
            size.sizeControlInstance,
            new FormControl(null, Validators.required)
          );

          this.productForm.patchValue({
            [size.sizeControlInstance]: product[size.sizeControlInstance],
          });
        });

        // add color controls to productForm then patch value to it
        this.colors.forEach((color) => {
          this.productForm.addControl(
            color.colorControlInstance,
            new FormControl(null, Validators.required)
          );

          this.productForm.patchValue({
            [color.colorControlInstance]: product[color.colorControlInstance],
          });
        });
        // end of patching dynamic form items (colors & sizes)

        // patch other fields
        this.productForm.patchValue({
          name: product.name,
          description: product.description,
          images: product.images,
          catId: product.catId,
          quantity: product.quantity,
          unitPrice: product.unitPrice,
          salePrice: product.salePrice,
          saleAmount: product.saleAmount,
        });
      });
  }

  onChange(): void {
    const selected_cate: NzTreeNode = this.treeSelect.getSelectedNodeList()[0];

    if (selected_cate) {
      this.productForm.patchValue({
        catTitle: selected_cate.origin.title,
        parentCatId: selected_cate.origin.parentId || null,
      });
    }
  }

  // sizes control
  addSizeField(e?: MouseEvent): void {
    if (e) {
      e.preventDefault();
    }
    const id =
      this.sizes.length > 0 ? this.sizes[this.sizes.length - 1].id + 1 : 0;

    const control = {
      id,
      sizeControlInstance: `sizes${id}`,
    };
    const index = this.sizes.push(control);
    // console.log(this.sizes[this.sizes.length - 1], index, this.sizes);
    this.productForm.addControl(
      this.sizes[index - 1].sizeControlInstance,
      new FormControl(null, Validators.required)
    );
  }

  removeSizeField(
    i: { id: number; sizeControlInstance: string },
    e: MouseEvent
  ): void {
    e.preventDefault();
    if (this.sizes.length > 1) {
      const index = this.sizes.indexOf(i);
      this.sizes.splice(index, 1);
      this.productForm.removeControl(i.sizeControlInstance);
    }
  }

  // colos control
  addColorField(e?: MouseEvent): void {
    if (e) {
      e.preventDefault();
    }
    const id =
      this.colors.length > 0 ? this.colors[this.colors.length - 1].id + 1 : 0;

    const control = {
      id,
      colorControlInstance: `colors${id}`,
    };
    const index = this.colors.push(control);
    // console.log(this.colors[this.colors.length - 1]);
    this.productForm.addControl(
      this.colors[index - 1].colorControlInstance,
      new FormControl(null, Validators.required)
    );
  }

  removeColorField(
    i: { id: number; colorControlInstance: string },
    e: MouseEvent
  ): void {
    e.preventDefault();
    if (this.colors.length > 1) {
      const index = this.colors.indexOf(i);
      this.colors.splice(index, 1);
      this.productForm.removeControl(i.colorControlInstance);
    }
  }

  calculateSalePrice() {
    const unitPrice = this.productForm.value.unitPrice || 0;
    const saleAmount = this.productForm.value.saleAmount || 0;

    let sale_price = 0;

    if (this.debouncer) clearTimeout(this.debouncer);

    this.debouncer = setTimeout(() => {
      if (unitPrice && saleAmount) {
        sale_price = unitPrice - (unitPrice * saleAmount) / 100;
      }
      this.productForm.patchValue({
        salePrice: sale_price || null,
      });
    }, 400);
  }

  // handle images upload
  handlePreview = async (file: NzUploadFile): Promise<void> => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj!);
    }
    this.previewImage = file.url || file.preview;
    this.previewVisible = true;
  };

  customRequest = (item: any): any => {
    const file_path = `VLYN-images/${Date.now()}`;
    const file_ref = this.fireStorage.ref(file_path);
    return this.fireStorage
      .upload(file_path, item.file)
      .snapshotChanges()
      .subscribe({
        error: (err: any) => {
          item.onError(err, item.file);
        },
        complete: async () => {
          const downloadURL = file_ref.getDownloadURL();
          downloadURL.pipe(filter((url) => !!url)).subscribe((url: string) => {
            this.images.push(url);
            this.productForm.patchValue({ images: this.images });

            item.onSuccess(item.file);
          });
        },
      });
  };

  handleUploadRemove = (file: NzUploadFile): boolean => {
    const removed_img_url = file.url;
    const removed_img_id = this.images.findIndex(
      (img) => img === removed_img_url
    );

    this.images.splice(removed_img_id, 1);

    this.productForm.patchValue({
      images: this.images,
    });

    if (this.images.length === 0) {
      this.productForm.patchValue({
        images: null,
      });
    }

    return true;
  };
  
  handleSearch() {
    if (!this.searchValue) {
      this.products = [...this.totalProducts];
      return;
    }
    this.products = this.totalProducts.filter(p => p.name.search(new RegExp(this.searchValue, 'i')) > -1);
    console.log(this.products)
    // const search_value = this.searchBox?.nativeElement.value;
    // if (search_value && search_value?.length > 0) {
    //   // this.router.navigate(['/products/search'], {
    //   //   queryParams: {
    //   //     keyword: search_value,
    //   //   },
    //   // });
    // }
  }
}
