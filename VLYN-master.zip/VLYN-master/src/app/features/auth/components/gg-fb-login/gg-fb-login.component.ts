import { Component, OnInit } from '@angular/core';
import { AuthService } from "src/app/core/services/auth.service";
import { NzModalService } from "ng-zorro-antd/modal";
import { Location } from "@angular/common";

@Component({
  selector: 'app-gg-fb-login',
  templateUrl: './gg-fb-login.component.html',
  styleUrls: ['./gg-fb-login.component.css']
})
export class GgFbLoginComponent implements OnInit {

  constructor(
      private authService: AuthService,
      private modal: NzModalService,
      private location: Location
  ) { }

  ngOnInit(): void {
  }
  
  onLoginWithGoogle() {
    this.authService.GoogleAuth().then(
        (res) => {
          this.modal.success({
            nzTitle: 'Đăng nhập thành công',
            nzClosable: false,
            nzOnOk: () => {
              this.location.back();
            },
          });
        },
        ( error ) => {
          this.modal.error({
            nzTitle: error.toString(),
            nzClosable: false,
          });
        }
    );
  }
}
