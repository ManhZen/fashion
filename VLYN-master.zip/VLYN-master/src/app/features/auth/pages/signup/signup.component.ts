import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { NzModalService } from 'ng-zorro-antd/modal';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {
  signUpForm: FormGroup;
  passwordVisible = false;
  confirmPasswordVisible = false;

  constructor(
    private authService: AuthService,
    private fb: FormBuilder,
    private modal: NzModalService,
    private location: Location
  ) {
    this.signUpForm = fb.group({
      email: [
        null,
        [
          Validators.required,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$'),
        ],
      ],
      password: [
        null,
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(255),
        ],
      ],
      confirmPassword: [
        null,
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(255),
        ],
      ],
    });
  }

  ngOnInit(): void {}

  onClickSignUp(): void {
    const { email, password, confirmPassword } = this.signUpForm.value;
    if (password !== confirmPassword || this.signUpForm.invalid) {
      return this.onErrorModal('Vui lòng kiểm tra lại thông tin');
    }
    this.authService.SignUp(email, password).then(
      () => {
        this.modal.success({
          nzTitle: 'Đăng ký thành công',
          nzClosable: false,
          nzOnOk: () => {
            this.location.back();
          },
          nzCentered: true,
        });
      },
      (err) => {
        this.onErrorModal(err);
      }
    );
  }

  private onErrorModal(msg: string) {
    this.modal.error({
      nzTitle: msg,
      nzClosable: false,
      nzCentered: true,
    });
  }

  isFieldInvalid(form: FormGroup, field: string, error: string): boolean {
    return (
      !!form.get(field)?.touched &&
      !form.get(field)?.valid &&
      !!form.get(field)?.hasError(error)
    );
  }
}
