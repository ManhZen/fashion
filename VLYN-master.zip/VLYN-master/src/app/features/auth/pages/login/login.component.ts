import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { NzModalService } from 'ng-zorro-antd/modal';
import { AuthService } from 'src/app/core/services/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  passwordVisible = false;

  constructor(
    private authService: AuthService,
    private fb: FormBuilder,
    private modal: NzModalService,
    private location: Location
  ) {
    this.loginForm = this.fb.group({
      email: [
        null,
        [
          Validators.required,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$'),
        ],
      ],
      password: [
        null,
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(255),
        ],
      ],
    });
  }

  ngOnInit(): void {}

  onLogin() {
    const { email, password } = this.loginForm.value;
    this.authService.SignIn(email, password).then(
      () => {
        this.modal.success({
          nzTitle: 'Đăng nhập thành công',
          nzClosable: false,
          nzOnOk: () => {
            this.location.back();
          },
          nzCentered: true,
        });
      },
      (error) => {
        const errMessage = `Tên đăng nhập hoặc tài khoản của bạn không chính xác.\n Vui lòng nhập lại tên đăng nhập hoặc mật khẩu`;
        this.modal.error({
          nzTitle: errMessage,
          nzClosable: false,
          nzCentered: true,
        });
      }
    );
  }

  isFieldInvalid(form: FormGroup, field: string, error: string): boolean {
    return (
      !!form.get(field)?.touched &&
      !form.get(field)?.valid &&
      !!form.get(field)?.hasError(error)
    );
  }
}
