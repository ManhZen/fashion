import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartItemsComponent } from './pages/cart-items/cart-items.component';
import { CheckoutComponent } from './pages/checkout/checkout.component';
import { Routes, RouterModule } from '@angular/router';

// ng-zorro
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPopconfirmModule } from 'ng-zorro-antd/popconfirm';

// shared components
import { QuantityInputModule } from 'src/app/shared-components/quantity-input/quantity-input.module';
import { BillingAddressFormModule } from 'src/app/shared-components/billing-address-form/billing-address-form.module';
import { NzModalModule } from 'ng-zorro-antd/modal';

const routes: Routes = [
  { path: 'cart-items', component: CartItemsComponent },
  { path: 'checkout', component: CheckoutComponent },
];

@NgModule({
  declarations: [CartItemsComponent, CheckoutComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),

    // shared components
    QuantityInputModule,
    BillingAddressFormModule,

    // ng zorro
    NzTableModule,
    NzModalModule,
    NzPopconfirmModule,
  ],
})
export class CartModule {}
