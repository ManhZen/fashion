import { Component, OnInit } from '@angular/core';
import { ICartItem } from 'src/app/core/models';
import { CartService } from 'src/app/core/services/cart.service';
import { takeUntil, tap } from 'rxjs/operators';
import { DestroyService } from 'src/app/core/services/destroy.service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart-items',
  templateUrl: './cart-items.component.html',
  styleUrls: ['./cart-items.component.css'],
})
export class CartItemsComponent implements OnInit {
  cart_items: ICartItem[] = [];
  checked = false;
  setOfCheckedId = new Set<string>();
  setOfCheckedItem = new Set<ICartItem>();
  isVisible = false;
  onDeleteItem: ICartItem;

  constructor(
    private cartService: CartService,
    private destroy$: DestroyService,
    private modal: NzModalService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.cartService.cart$.pipe(takeUntil(this.destroy$)).subscribe((cart) => {
      this.cart_items = cart;
    });

    this.cartService.selectedCartItems$
      .pipe(
        tap((items: ICartItem[]) => {
          items.forEach((_item: ICartItem) => {
            this.setOfCheckedItem.add(_item);
            this.setOfCheckedId.add(_item.id);
          });
        }),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.checkIfAllChecked();
      });
  }

  updateCheckedSet(data: ICartItem, checked: boolean): void {
    if (checked) {
      this.setOfCheckedItem.add(data);
      this.setOfCheckedId.add(data.id);
    } else {
      this.setOfCheckedItem.delete(data);
      this.setOfCheckedId.delete(data.id);
    }

    this.checkIfAllChecked();

    this.cartService.selectCartItems([...this.setOfCheckedItem]);
  }

  onCheckOut(): void {
    if (this.setOfCheckedItem.size) {
      this.router.navigate(['cart/checkout']);
    } else {
      this.onWarningModal();
    }
  }

  onAllChecked(checked: boolean): void {
    this.cart_items.forEach((item) => this.updateCheckedSet(item, checked));
  }

  add(inputQuantity: number, _item: ICartItem): void {
    _item.quantity = inputQuantity;
    this.cartService.onChangeQuantity(inputQuantity, _item);
  }

  remove(inputQuantity: number, _item: ICartItem): void {
    if (inputQuantity === 0) {
      this.handleConfirmRemoveItem();
      this.onDeleteItem = _item;
    }
    _item.quantity = inputQuantity;
    this.cartService.onChangeQuantity(inputQuantity, _item);
  }

  checkIfAllChecked(): void {
    this.cart_items.length === this.setOfCheckedItem.size
      ? (this.checked = true)
      : (this.checked = false);
  }

  onWarningModal(): void {
    this.modal.warning({
      nzTitle: 'Bạn chưa chọn mua sản phẩm nào',
      nzMaskClosable: true,
      nzCentered: true,
    });
  }

  removeItem(data: any): void {
    this.cartService.removeItemInCart(data.id, data.sku);
  }

  handleConfirmRemoveItem() {
    this.isVisible = true;
    this.modal.confirm({
      nzTitle: 'Bạn muốn bỏ sản phẩm này?',
      nzContent: '',
      nzOkText: 'Đồng ý',
      nzCancelText: 'Hủy',
      nzOnOk: () => {
        const { id, sku } = this.onDeleteItem;
        this.cartService.removeItemInCart(id, sku);
      },
      nzOnCancel: () => {
        this.cartService.revertItemQuantity(this.onDeleteItem);
      },
    });
  }

  handleCancelRemoveItem(): void {
    this.isVisible = false;
  }
}
