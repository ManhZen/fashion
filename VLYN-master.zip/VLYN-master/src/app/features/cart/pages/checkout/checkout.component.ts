import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NzModalService } from 'ng-zorro-antd/modal';
import { catchError, takeUntil, tap } from 'rxjs/operators';
import { OrderStatus } from 'src/app/core/enums';
import { ICartItem, IOrder, IUser } from 'src/app/core/models';
import { AuthService } from 'src/app/core/services/auth.service';
import { CartService } from 'src/app/core/services/cart.service';
import { DestroyService } from 'src/app/core/services/destroy.service';
import { OrderService } from 'src/app/core/services/order.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css'],
})
export class CheckoutComponent implements OnInit {
  price = 0;
  amount = 0;
  isGetFormValue = false;
  checkout_items: ICartItem[] = JSON.parse(
    localStorage.getItem('carts_in_storage') || '[]'
  ) as ICartItem[];

  order: IOrder = {
    id: '',
    items: this.checkout_items,
    status: OrderStatus.PLACED,
    price: this.price,
    totalPayment: 0,
    shippingCost: 0,
    discountCost: 0,
    amount: this.amount,
    fullName: '',
    phone: '',
    provinceId: '',
    districtId: '',
    wardId: '',
    address: '',
    paymentMethodId: '',
    deliveryMethodId: '',
    buyer_id: '',
  };
  address: any;
  isInValidForm = true;

  currentUser: IUser;

  constructor(
    private cartService: CartService,
    private destroy$: DestroyService,
    private modal: NzModalService,
    private router: Router,
    private orderService: OrderService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.authService.currentUser$
      .pipe(takeUntil(this.destroy$))
      .subscribe((currentUser) => (this.currentUser = currentUser));

    this.cartService.selectedCartItems$
      .pipe(
        tap((_items) => {
          if (!_items.length && !this.checkout_items.length) {
            throw 'Bạn chưa chọn mua sản phẩm nào';
          }
          this.price = 0;
          if (_items.length) {
            _items.forEach((_item) => {
              this.price += _item.quantity * _item.price;
              this.amount += _item.quantity;
            });
          } else {
            this.checkout_items.forEach((_item) => {
              this.price += _item.quantity * _item.price;
              this.amount += _item.quantity;
            });
          }
        }),
        takeUntil(this.destroy$),
        catchError((err) => {
          throw 'error in source. Details: ' + err;
        })
      )
      .subscribe(
        (_items: ICartItem[]) => {
          if (_items.length) {
            this.checkout_items = _items;
          }
        },
        (err) => {
          this.onWarningModal(err, true);
        }
      );
  }

  setAddressForm(address: any): void {
    this.address = address;
  }

  async onSubmit() {
    let totalPrice = 0;
    this.checkout_items.forEach((item) => {
      totalPrice += item.quantity * item.price;
    });
    this.order = Object.assign(this.order, this.address);
    this.order = {
      ...this.order,
      items: this.checkout_items,
      totalPayment: totalPrice,
    };
    try {
      await this.orderService.createOrder(this.order, this.currentUser);
      this.onSuccessModal('Đặt hàng thành công');
      this.cartService.removeCart();
    } catch (err: any) {
      this.onWarningModal(err);
    }
  }

  onWarningModal(message: string, redirect?: boolean): void {
    this.modal.warning({
      nzTitle: message,
      nzClosable: false,
      nzOnOk: () => {
        if (redirect) {
          this.router.navigate(['/cart/cart-items']);
        }
      },
      nzCentered: true,
    });
  }

  onSuccessModal(message: string): void {
    this.modal.success({
      nzTitle: message,
      nzClosable: false,
      nzOnOk: () => {
        this.router.navigate(['/management/orders']);
      },
      nzCentered: true,
    });
  }

  getInValidForm(isInValid: boolean): void {
    this.isInValidForm = isInValid;
  }
}
