export type ProductSkus = 'size' | 'color' | 'quantity' | 'address';
