import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// components
import { ProductItemComponent } from './components/product-item/product-item.component';
import { DetailComponent } from './pages/detail/detail.component';
import { LatestComponent } from './pages/latest/latest.component';
import { SalesComponent } from './pages/sales/sales.component';
import { SearchResultComponent } from './pages/search-result/search-result.component';
import { CategoryDetailComponent } from './pages/category-detail/category-detail.component';

// featured modules
import { BillingAddressFormModule } from 'src/app/shared-components/billing-address-form/billing-address-form.module';
import { QuantityInputModule } from 'src/app/shared-components/quantity-input/quantity-input.module';

// ng zorro modules
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { FormsModule } from '@angular/forms';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';

const routes: Routes = [
  { path: 'latest', component: LatestComponent },
  { path: 'sales', component: SalesComponent },
  { path: 'category/:alias', component: CategoryDetailComponent },
  { path: 'search', component: SearchResultComponent },
  { path: ':productId', component: DetailComponent },
];

@NgModule({
  declarations: [
    LatestComponent,
    SalesComponent,
    ProductItemComponent,
    DetailComponent,
    CategoryDetailComponent,
    SearchResultComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),

    // feature modules
    QuantityInputModule,
    BillingAddressFormModule,

    // ng zorro
    NzSelectModule,
    NzModalModule,
    NzButtonModule,
    FormsModule,
    NzPaginationModule,
  ],
})
export class ProductsModule {}
