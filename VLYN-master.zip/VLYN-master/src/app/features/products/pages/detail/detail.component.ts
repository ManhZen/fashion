import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/core/services/product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { IProduct } from '../../../../core/models/product.model';
import { ICartItem } from 'src/app/core/models';
import { CartService } from 'src/app/core/services/cart.service';
import { DestroyService } from 'src/app/core/services/destroy.service';
import { ProductSkus } from 'src/app/features/products/models/models';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzModalService } from 'ng-zorro-antd/modal';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css'],
})
export class DetailComponent implements OnInit {
  quantity: number = 1;
  selected_color: string = '';
  isModalVisible = false;

  product: IProduct = {
    id: '',
    name: '',
    description: '',
    alias: '',
    catId: '',
    catTitle: '',
    quantity: 0,
    orderedAmount: 0,
    unitPrice: 0,
    saleAmount: 0,
    salePrice: 0,
    images: [],
    colors: [],
    sizes: [],
  };

  cart_item: ICartItem = {
    id: '',
    name: '',
    price: 0,
    quantity: 0,
    sku: '',
    address: null,
    maxQuantity: 1,
  };

  product_sizes: string[] = [];
  product_colors: string[] = [];
  isInvalidForm = true;
  color: string;

  productSkuMap: Record<ProductSkus, string | number> = {
    size: '',
    color: '',
    address: '',
    quantity: 0,
  };

  address: any;

  cartItemForm: FormGroup;

  isLoggedIn = false;

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private router: Router,
    private cartService: CartService,
    private destroy$: DestroyService,
    private formBuilder: FormBuilder,
    private modal: NzModalService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.isLoggedIn = this.authService.isLoggedIn;

    this.cartItemForm = this.formBuilder.group({
      color: [null, Validators.required],
      size: [null, Validators.required],
      quantity: [1],
    });

    const { productId } = this.route.snapshot.params;

    this.productService
      .getSingleProduct(productId)
      .pipe(takeUntil(this.destroy$))
      .subscribe((product) => {
        this.product = product;
        // patch dynamic form items (colors & sizes)
        const product_entries = Object.entries(product);

        // get all sizes properties then put into an array
        const size_entries = product_entries.filter((entry) =>
          entry.some(
            (element) =>
              typeof element === 'string' && element.includes('sizes')
          )
        );

        this.product_sizes = size_entries.map((entry) =>
          entry.find((element) => !element.includes('sizes'))
        );

        // get all colors properties then put into an array
        const color_entries = product_entries.filter((entry) =>
          entry.some(
            (element) =>
              typeof element === 'string' && element.includes('colors')
          )
        );

        this.product_colors = color_entries.map((entry) =>
          entry.find((element) => !element.includes('colors'))
        );
      });
  }

  showBillingAddressModal() {
    this.isModalVisible = true;
  }

  // handleOk(event: any): void {
  //   this.isModalVisible = false;
  // }

  handleCancel(): void {
    this.isModalVisible = false;
  }

  add(inputQuantity: number): void {
    this.quantity = inputQuantity;
  }

  remove(inputQuantity: number): void {
    this.quantity = inputQuantity;
  }

  addToCart(isRedirect: boolean): void {
    if (!this.isLoggedIn) {
      this.modal.warning({
        nzTitle: 'Vui lòng đăng nhập để thực hiện tính năng',
        nzOkText: 'Đăng nhập',
        nzCentered: true,
        nzMaskClosable: true,
        nzOnOk: () => {
          this.router.navigate(['/auth/login']);
        },
      });

      return;
    }

    if (this.cartItemForm.invalid) {
      let error = '';
      if (
        this.cartItemForm.get('color')?.invalid &&
        this.cartItemForm.get('size')?.invalid
      ) {
        error = 'Vui lòng chọn màu sắc và kích cỡ';
      }

      if (this.cartItemForm.get('color')?.invalid) {
        error = 'Vui lòng chọn màu sản phẩm';
      }

      if (this.cartItemForm.get('size')?.invalid) {
        error = 'Vui lòng chọn kích cỡ sản phẩm';
      }

      this.modal.error({
        nzTitle: error,
        nzCentered: true,
      });
      return;
    }

    this.productSkuMap = {
      ...this.productSkuMap,
      quantity: this.quantity,
      color: this.color,
      address: this.address,
    };

    const { productId } = this.route.snapshot.params;

    this.cart_item = {
      id: productId,
      name: this.product.name,
      price: this.product.salePrice ?? this.product.unitPrice,
      quantity: this.quantity,
      sku: this.getSkuString(),
      address: this.address,
      maxQuantity: this.product.quantity,
    };

    this.cartService.addToCart(this.cart_item);

    // navigate to cart in case user click Buy Now
    if (isRedirect) {
      this.router.navigate(['/cart/cart-items']);
      return;
    }

    this.modal.success({
      nzTitle: 'Sản phẩm đã được thêm vào giỏ hàng',
      nzOkText: 'Xem giỏ hàng',
      nzCentered: true,
      nzMaskClosable: true,
      nzOnOk: () => {
        this.router.navigate(['/cart/cart-items']);
      },
    });
  }

  getSkuString(): string {
    return (
      'Màu: ' +
      this.productSkuMap['color'] +
      ', size: ' +
      this.productSkuMap['size']
    );
  }

  isInValidForm(_isInvalid: boolean): void {
    this.isInvalidForm = _isInvalid;
  }

  selectSize(size: string): void {
    this.cartItemForm.patchValue({
      size,
    });
    this.productSkuMap = {
      ...this.productSkuMap,
      size,
    };
  }

  selectColor(color: string) {
    this.cartItemForm.patchValue({
      color,
    });
  }

  setAddressFormValue(address: any): void {
    this.address = address;
  }

  changeQuantity(_quantity: number): void {
    if (_quantity <= 0) {
      this.quantity = 1;
      return;
    }
    const { quantity } = this.product;
    if (_quantity >= quantity) {
      this.quantity = quantity;
      return;
    }
    this.quantity = _quantity;
  }
}
