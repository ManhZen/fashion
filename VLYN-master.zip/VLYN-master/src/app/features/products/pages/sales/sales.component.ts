import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/core/services/product.service';
import { IProduct } from 'src/app/core/models';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['../latest/latest.component.css'],
})
export class SalesComponent implements OnInit {
  private readonly destroy$ = new Subject();

  products: IProduct[] = [];

  page_categories: any[] = [];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService
      .getSaleProducts()
      .pipe(takeUntil(this.destroy$))
      .subscribe((products) => {
        // get all sales badge, put them in unique array using Set then sort them in ascending order
        this.page_categories = [
          ...new Set(products.map((product) => +product.saleAmount!)),
        ].sort((a: number, b: number) => {
          return a - b;
        });
        this.products = products;
      });
  }

  getProductsFromCate(saleAmount: number) {
    let full_arr = this.products.filter(
      (product) => product.saleAmount === saleAmount
    );

    let chunken_arr = this.chunkArr(full_arr, 4);
    return chunken_arr;
  }

  chunkArr(arr: any[], length: number) {
    let chunks = [],
      i = 0,
      n = arr.length;

    while (i < n) {
      chunks.push(arr.slice(i, (i += length)));
    }

    return chunks;
  }

  scrollToElement(id: string) {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
