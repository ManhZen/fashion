import { Component, OnDestroy, OnInit } from '@angular/core';
import { ProductService } from 'src/app/core/services/product.service';
import { IProduct } from 'src/app/core/models';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css'],
})
export class SearchResultComponent implements OnInit, OnDestroy {
  results: IProduct[] = [];
  searchValue = '';
  destroy$ = new Subject();

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.productService.searchResults$
      .pipe(takeUntil(this.destroy$))
      .subscribe((results) => {
        this.results = results;
      });

    this.route.queryParams.subscribe((queryParams: Params) => {
      this.searchValue = queryParams.keyword;
      this.productService.searchProducts(this.searchValue);
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
