import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/core/services/product.service';
import { IProduct } from 'src/app/core/models';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-latest',
  templateUrl: './latest.component.html',
  styleUrls: ['./latest.component.css'],
})
export class LatestComponent implements OnInit {
  private readonly destroy$ = new Subject();

  products: IProduct[] = [];

  page_categories: string[] = [];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService
      .getLatestProducts()
      .pipe(takeUntil(this.destroy$))
      .subscribe((products) => {
        this.page_categories = [
          ...new Set(products.map((product) => product.catTitle)),
        ];
        this.products = products;
      });
  }

  getProductsFromCate(catTitle: string) {
    let full_arr = this.products.filter(
      (product) => product.catTitle === catTitle
    );

    let chunken_arr = this.chunkArr(full_arr, 4);
    return chunken_arr;
  }

  chunkArr(arr: any[], length: number) {
    let chunks = [],
      i = 0,
      n = arr.length;

    while (i < n) {
      chunks.push(arr.slice(i, (i += length)));
    }

    return chunks;
  }

  scrollToElement(id: string) {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
