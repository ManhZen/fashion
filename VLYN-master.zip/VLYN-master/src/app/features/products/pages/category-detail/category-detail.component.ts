import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/core/services/product.service';
import { ActivatedRoute, Params } from '@angular/router';
import { IProduct } from 'src/app/core/models';

@Component({
  selector: 'app-category-detail',
  templateUrl: './category-detail.component.html',
  styleUrls: ['../search-result/search-result.component.css'],
})
export class CategoryDetailComponent implements OnInit {
  catTitle = '';
  cateId = '';
  products: IProduct[] = [];
  totalProducts: IProduct[] = [];
  pageSize = 16;
  pageIndex = 1;
  constructor(
    private productService: ProductService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params: Params) => {
      this.catTitle = params.alias;
      this.cateId = this.route.snapshot.queryParams['cateId'];

      this.productService
        .getProductByCate(this.cateId)
        .subscribe((products) => {
          this.totalProducts = products;
          if (this.totalProducts.length > this.pageSize) {
            this.products = this.totalProducts.slice(0, this.pageSize);
          } else {
            this.products = this.totalProducts;
          }
        });
    });
  }

  onChangePageIndex(index: number): void {
    this.pageIndex = index;
    const begin = (this.pageIndex - 1) * this.pageSize;
    const end = begin + this.pageSize;
    this.products = this.totalProducts.slice(begin, end);
    this.gotoTop();
  }
  
  private gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
}
