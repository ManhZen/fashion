import { Component, Input, OnInit } from '@angular/core';
import { IProduct } from 'src/app/core/models';

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css'],
})
export class ProductItemComponent implements OnInit {
  @Input() product: IProduct = {
    id: '',
    name: '',
    description: '',
    alias: '',
    catId: '',
    catTitle: '',
    quantity: 0,
    orderedAmount: 0,
    unitPrice: 0,
    saleAmount: 0,
    salePrice: 0,
    images: [],
    colors: [],
    sizes: [],
  };
  @Input() height: number = 0;

  constructor() {}

  ngOnInit(): void {}
}
