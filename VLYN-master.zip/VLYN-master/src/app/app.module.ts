import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutComponent } from './layout/main-layout/layout.component';
import { ManagementLayoutComponent } from './layout/management-layout/management-layout.component';

// feature modules
import { HeaderModule } from './shared-components/header/header.module';
import { FooterModule } from './shared-components/footer/footer.module';

// ng zorro
// 1. antd icons registration
import { NZ_ICONS } from 'ng-zorro-antd/icon';
import { IconDefinition } from '@ant-design/icons-angular';
import * as AllIcons from '@ant-design/icons-angular/icons';

const antDesignIcons = AllIcons as {
  [key: string]: IconDefinition;
};
const icons: IconDefinition[] = Object.keys(antDesignIcons).map(
  (key) => antDesignIcons[key]
);
// end of antd icons registration

// 2. antd language setup
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';
import { NZ_I18N, en_US } from 'ng-zorro-antd/i18n';

registerLocaleData(en);
// end of antd language setup

// 3. antd featured modules
import { NzTreeModule } from 'ng-zorro-antd/tree';
import { NzMenuModule } from 'ng-zorro-antd/menu';

// firebase
import { environment } from 'src/environments/environment';
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFirestoreModule } from '@angular/fire/compat/firestore';
import { AngularFireStorageModule } from '@angular/fire/compat/storage';
import { AngularFireAuthModule } from '@angular/fire/compat/auth';
@NgModule({
  declarations: [AppComponent, LayoutComponent, ManagementLayoutComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,

    // feature modules
    HeaderModule,
    FooterModule,

    // ng zorro modules
    NzMenuModule,
    NzTreeModule,

    // firebase
    AngularFireModule.initializeApp(environment.firebase),
    AngularFirestoreModule,
    AngularFireStorageModule,
    AngularFireAuthModule,
  ],
  providers: [
    { provide: NZ_I18N, useValue: en_US }, // language setup
    { provide: NZ_ICONS, useValue: icons }, // antd icons registration
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
