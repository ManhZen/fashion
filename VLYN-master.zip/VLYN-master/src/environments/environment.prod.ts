export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyADBRGlS1h-708SjiNf0vpZpHTiDD2gIxw',
    authDomain: 'vlyn-a9cfc.firebaseapp.com',
    projectId: 'vlyn-a9cfc',
    storageBucket: 'vlyn-a9cfc.appspot.com',
    messagingSenderId: '70539755106',
    appId: '1:70539755106:web:b852cf9138b5421ef8db3b',
    measurementId: 'G-E58LS5P3M1',
  },
};
